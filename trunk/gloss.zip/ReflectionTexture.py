import clutter

class Texture_Reflection (clutter.Texture):

    def __init__(self, origTexture):
        clutter.Texture.__init__(self)
        self.set_pixbuf(origTexture.get_pixbuf())
        
        self.set_width(origTexture.get_width())
        self.set_height(origTexture.get_height())
        
        #There doesn't seem to be a way to test for a rotation :(
        #if origTexture.
        self.rotate_y(45,0,0)
               
        (orig_x, orig_y) = origTexture.get_abs_position()
        x = orig_x
        y = orig_y# + origTexture.get_height()

        
        #self.set_clip(0,self.get_height()/2,self.get_width(), (self.get_height()/2))
        self.rotate_x(180,origTexture.get_height(),0)
        self.set_opacity(50)
        
        #self.set_height(200)
        self.set_position(x, y)