import clutter
import time
import os.path
import pygtk
import gtk
import random
import thread

class Slideshow:
    fileTypes = ["jpg", "gif", "jpeg", "png", "bmp"]
    imageDuration = 5 # In seconds
    effect_FPS = 50

    def __init__(self):
        self.image_texture_group = clutter.Group()
        self.currentTexture = clutter.Texture()
        self.paused = False
        self.overlay = clutter.Rectangle()
        
    def on_key_press_event (self, stage, event):
        #print event.hardware_keycode
        if event.keyval == clutter.keysyms.p:
            if self.paused:
                self.unpause()
            else:
                self.pause()
        if event.keyval == clutter.keysyms.q:
            clutter.main_quit()
        
    def loadDir(self, dirPath):
        if not os.path.isdir(dirPath):
            print "ERROR: Invalid path"
            return None
        
        new_file_list = os.listdir(dirPath)
        new_file_list = filter(self.filterFile, new_file_list)
        self.fileList = new_file_list        
        #print new_file_list
        
        i = 0   
        
        self.textures = []
        for pic in new_file_list:
            self.textures.append(clutter.Texture())
            imgName = "images/"+pic
            pixbuf = gtk.gdk.pixbuf_new_from_file(imgName)
            self.textures[i].set_pixbuf(pixbuf)
            self.textures[i].set_position(0,0)
            self.image_texture_group.add(self.textures[i])
            i = i+1
        
    def appendDir(self, dirPath):
        if not os.path.isdir(dirPath):
            print "ERROR: Invalid path"
            return None
        
        new_file_list = os.listdir(dirPath)
        new_file_list = filter(self.filterFile, new_file_list)
        self.fileList.append( new_file_list )
        
        self.textures = []
        i = 0     
        for pic in new_file_list:
            self.textures[i] = clutter.Texture()
            imgName = "images/"+pic
            pixbuf = gtk.gdk.pixbuf_new_from_file(imgName)
            self.textures[i].set_pixbuf(pixbuf)
            self.textures[i].set_position(0,0)
            self.image_texture_group.add(self.textures[i])
            i = i+1
        
    #This makes sure we only take in files with correct extensions
    def filterFile(self, fileName):
        extension = fileName[-3:] #Get 3 letter extension
        if extension in self.fileTypes:
            return True
        else:
            return False
    
    def begin(self, MenuMgr):
        self.stage = MenuMgr.get_stage()
        #stage.hide_all()
        
        
        #Create a rectangle that serves as the backdrop for the slideshow
        self.backdrop = clutter.Rectangle()
        self.backdrop.set_color(clutter.color_parse('Black'))
        self.backdrop.set_width(self.stage.get_width())
        self.backdrop.set_height(self.stage.get_height())
        self.backdrop.set_opacity(0)
        self.backdrop.show()
        self.stage.add(self.backdrop)
        #Fade the backdrop in
        timeline_backdrop = clutter.Timeline(10,30)
        alpha = clutter.Alpha(timeline_backdrop, clutter.ramp_inc_func)
        backdrop_behaviour = clutter.BehaviourOpacity(alpha, 0, 255)
        backdrop_behaviour.apply(self.backdrop)
        timeline_backdrop.start()
        
        
        #Hide the menu items (Basically everything on the stage)
        #self.old_background_colour = stage.get_color()
        #stage.set_color(clutter.Color(0, 0, 0, 0))
        
        self.stage.add(self.image_texture_group)
        #print "No of children: " + str(self.image_texture_group.get_n_children())
        #Get a random texture
        self.rand1 = random.randint(0, self.image_texture_group.get_n_children()-1)
        self.currentTexture = self.textures[self.rand1]
        #Make sure its visible
        self.currentTexture.set_opacity(255)

        self.image_texture_group.hide_all()
        self.currentTexture.show()
        self.image_texture_group.show()
        self.nextTexture = None
        
        #Begin the show
        self.nextImage(self.currentTexture)
        
    def end(self):
        pass

    
    def nextImage(self, currentTexture):
        #Setup stuff for KEN BURNS EFFECT!!
        self.timeline_main = clutter.Timeline((self.effect_FPS * self.imageDuration), self.effect_FPS)
        self.timeline_main.connect('completed', self.timeline_end_event)
        self.alpha = clutter.Alpha(self.timeline_main, clutter.ramp_inc_func)
        
        #Decide on the next texture to use
        self.nextTexture = None
        while self.nextTexture == None:
            self.rand1 = random.randint(0, len(self.textures))
            self.nextTexture = self.image_texture_group.get_nth_child(self.rand1)
            #Make sure we don't show the same photo twice
            if self.nextTexture == self.currentTexture:
                self.nextTexture = None
        #Make sure its not visible initially (Prevents a nasty flicker the first time a photo is shown)
        self.nextTexture.set_opacity(0)
               
        #Zooming stuff
        rand_zoom = random.uniform(1,1.3) # Zoom somewhere between 1 and 1.3 times
        self.behaviour1 = clutter.BehaviourScale(self.alpha, 1, rand_zoom, clutter.GRAVITY_CENTER)
        
        #panning stuff
        x_pos = self.currentTexture.get_x() + random.randint(-100, 100)
        y_pos = self.currentTexture.get_y() + random.randint(-100, 100)
        knots = (\
                (self.currentTexture.get_x(), self.currentTexture.get_y()),\
                (x_pos, y_pos)\
                )
        self.behaviour2 = clutter.BehaviourPath(self.alpha, knots)
            
        
        #Start and run the Ken Burns effect
        self.behaviour1.apply(self.currentTexture)
        self.behaviour2.apply(self.currentTexture)
        self.timeline_main.start()       

        
    def timeline_end_event(self, data):
        #Add the timeline for the dissolve at the end
        self.timeline_dissolve = clutter.Timeline(30,30)
        self.alpha_dissolve = clutter.Alpha(self.timeline_dissolve, clutter.ramp_inc_func)
    
        #Setup the dissolve to the next image
        self.behaviour3 = clutter.BehaviourOpacity(self.alpha_dissolve, 255, 0)
        self.behaviour4 = clutter.BehaviourOpacity(self.alpha_dissolve, 0, 255)
        
        self.behaviour3.apply(self.currentTexture)
        self.behaviour4.apply(self.nextTexture)
        
        #Pick a random spot for the next image
        x_pos = random.randint(0, (self.stage.get_width() - self.nextTexture.get_width()) ) #Somewhere between 0 and (stage_width-image_width)
        y_pos = random.randint(0, (self.stage.get_height() - self.nextTexture.get_height()) )
        self.nextTexture.set_position(x_pos, y_pos)
        
        self.currentTexture = self.nextTexture
        self.nextTexture.show()
        self.timeline_dissolve.start()
        self.nextImage(self.currentTexture)
        
    def pause(self):
        self.paused = True
    
        #Use the overlay to go over show
        self.overlay.set_color(clutter.color_parse('Black'))
        self.overlay.set_width(self.stage.get_width())
        self.overlay.set_height(self.stage.get_height())
        self.overlay.set_opacity(0)
        self.overlay.show()
        #self.overlay.raise_top()
        #self.image_texture_group.lower(self.overlay)
        self.stage.add(self.overlay)
        #Fade the backdrop in
        timeline_overlay = clutter.Timeline(10,30)
        alpha = clutter.Alpha(timeline_overlay, clutter.ramp_inc_func)
        overlay_behaviour = clutter.BehaviourOpacity(alpha, 0, 100)
        overlay_behaviour2 = clutter.BehaviourOpacity(alpha, 255, 100) #Used on the backdrop
        overlay_behaviour3 = clutter.BehaviourOpacity(alpha, 255, 0) #Used on the current texture
        overlay_behaviour.apply(self.overlay)
        overlay_behaviour2.apply(self.backdrop)
        overlay_behaviour3.apply(self.currentTexture)
        timeline_overlay.start()
        
        #Pause the main slideshow
        self.timeline_main.pause()
        
    def unpause(self):
        self.paused = False
        
        #self.overlay.raise_top()
        #self.image_texture_group.lower(self.overlay)
        #self.stage.add(self.overlay)
        #Fade the backdrop in
        timeline_overlay = clutter.Timeline(10,30)
        alpha = clutter.Alpha(timeline_overlay, clutter.ramp_inc_func)
        overlay_behaviour = clutter.BehaviourOpacity(alpha, 100, 0)
        overlay_behaviour2 = clutter.BehaviourOpacity(alpha, 100, 255) #Used on the backdrop
        overlay_behaviour3 = clutter.BehaviourOpacity(alpha, 0, 255) #Used on the current texture
        overlay_behaviour.apply(self.overlay)
        overlay_behaviour2.apply(self.backdrop)
        overlay_behaviour3.apply(self.currentTexture)
        timeline_overlay.start()
        
        #Resume the main slideshow
        self.timeline_main.start()
        
    def stop(self):
        #Stop any running timelines
        self.timeline_main.stop()
        #self.timeline_dissolve.stop()
    
        #Fade everything out
        timeline_stop = clutter.Timeline(10,30)
        alpha = clutter.Alpha(timeline_stop, clutter.ramp_inc_func)
        stop_behaviour = clutter.BehaviourOpacity(alpha, 255, 0)
        stop_behaviour.apply(self.image_texture_group)
        stop_behaviour.apply(self.backdrop)
        stop_behaviour.apply(self.overlay)
        timeline_stop.connect('completed', self.destroySlideshow)
        timeline_stop.start()
        
    def destroySlideshow(self, data):
        self.stage.remove(self.image_texture_group)
        self.stage.remove(self.backdrop)
        #self.stage.remove(self.overlay)
        