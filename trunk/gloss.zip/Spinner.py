import clutter

class Spinner_Alpha (clutter.Alpha):
    
    def __init__(self, timeline, function):
        clutter.Alpha.__init__ (self)
        self.timeline = timeline
        
    def spinner_alpha_func(self):
        factor = self.timeline.get_current_frame() / self.timeline.get_n_frames()
        #factor = alpha_value / CLUTTER_ALPHA_MAX_ALPHA;

        #/* Calculate the angle */
        angle = factor * 360.0;
        
        return angle

class BehaviourSpinner (clutter.BehaviourPath):

    def __init__(self, alpha):
        #clutter.Behaviour.__init__(self)
        clutter.BehaviourPath.__init__ (self)
        self.alpha = alpha
        
    def alpha_notify(self, alpha_value):
        print "ldskfjsldjf"
        angle = self.alpha.get_alpha() #spinner_alpha_func()
        
        x = self.actor.get_x() / 2
        y = self.actor.get_y() / 2
                
        self.actor.rotate_z(angle, x, y)
        self.actor.queue_redraw()
        

        
        